Designed as a basic back-end software for use in a store like environment all we had to do was make a system that could add remove,
 and edit items but I was having a lot of fun so I added a shopping cart and a bunch of other features. The original project couldn't 
 save changes so I added a .txt file to store the changes. I've also added some things like if you checkout before you quit it'll just say Thank you
 but if you quit before checking out it shows the checkout.
The file is ims.py 

There are other unrelated python project files as well.
